package be.ucll.eindopdracht.Service;


import be.ucll.eindopdracht.Model.Playlist;
import be.ucll.eindopdracht.Model.Song;
import be.ucll.eindopdracht.Model.User;
import be.ucll.eindopdracht.Repository.PlaylistRepository;
import be.ucll.eindopdracht.Repository.SongRepository;
import be.ucll.eindopdracht.Repository.UserRepository;
import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service //zonder deze annotatie weet het project niet dat deze klasse een service is
public class PlaylistService {
    //repo's
    @Autowired //inject automatisch repo beans als in PLservice - niet expliciet instantie maken
    private PlaylistRepository repo;
    @Autowired
    private UserRepository userRepo;
    @Autowired
    private SongRepository songRepo;

    @Transactional //alle stappen v createplaylist als geheel behandeld - exception: alles terug
    public Playlist createPlaylist(Long userId, Playlist playlist) {
        User user = userRepo.findById(userId)//Check si le user existe ou pas
                .orElseThrow(() -> new IllegalArgumentException("User not found with this id"));

        if (repo.findPlaylistByNameAndUserId(playlist.getName(), userId).isPresent()) {//Checkt of playlist al bestaande is voor een user
            throw new IllegalArgumentException("Playlist name must be unique for the user");//Throw exception
        }

        playlist.setUser(user);//user aan een playlist toeschrijven
        return repo.save(playlist);//Save: methode van JpaRepository
    }

    public Playlist addSongToPlaylist(Long userId, Long playlistId, Long songId) {

        if (!userRepo.existsById(userId)) {
            throw new IllegalArgumentException("User not found with this id " + userId);
        }
        Playlist playlist = repo.findById(playlistId)
                .orElseThrow(() -> new IllegalArgumentException("Playlist not found with this id " + playlistId));

        Song song = songRepo.findById(songId)
                .orElseThrow(() -> new IllegalArgumentException("Song not found with this id " + songId));

        if (!playlist.getUser().getId().equals(userId)) {
            throw new IllegalArgumentException("Playlist does not belong to user with this id  " + userId);
        }

        if (playlist.getSongs().size() >= playlist.getAantal_liedjes()) {
            throw new EntityNotFoundException("Playlist is full");
        }

        playlist.getSongs().add(song);

        return repo.save(playlist);
    }

    public void removeSongFromPlaylist(Long userId, Long playlistId, Long songId) {
        Playlist playlist = repo.findById(playlistId)
                .orElseThrow(() -> new EntityNotFoundException("Playlist not found"));

        Song song = songRepo.findById(songId)
                .orElseThrow(() -> new EntityNotFoundException("Song not found"));

        if (!playlist.getUser().getId().equals(userId)) {
            throw new EntityNotFoundException("User not found");
        }

        if (!playlist.getSongs().contains(song)) {
            throw new EntityNotFoundException("Song not in the playlist");
        }

        playlist.getSongs().remove(song);
        repo.save(playlist);
    }


}
