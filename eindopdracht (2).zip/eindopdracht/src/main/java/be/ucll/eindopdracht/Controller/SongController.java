package be.ucll.eindopdracht.Controller;


import be.ucll.eindopdracht.Model.Song;
import be.ucll.eindopdracht.Model.User;
import be.ucll.eindopdracht.Repository.SongRepository;
import be.ucll.eindopdracht.Service.SongService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/v1")
public class SongController {

    @Autowired
    private SongService service;
//    @Autowired
//    private SongRepository repo;

    @GetMapping("songs")
    public List<Song> getAllSongs(){

        return service.getAllTheSongs();
    }

    @PostMapping("song")
    public ResponseEntity<Song> saveSong(@RequestBody Song song){
        return new ResponseEntity<>(service.saveTheSong(song), HttpStatus.CREATED);
    }

    @PutMapping("song/{id}")
    public ResponseEntity<Song> updatePartner(@PathVariable(value = "id") Long id, @RequestBody Song song) {
        song.setId(id);
        return new ResponseEntity<>(service.updateSong(song), HttpStatus.OK);
    }

    @GetMapping("song")
    public ResponseEntity<List<Song>> getSongsByAlbum(@RequestParam String album) {
        List<Song> songs = service.getSongsByAlbum(album);
        if (songs.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(songs, HttpStatus.OK);
    }


}
