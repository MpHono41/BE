package be.ucll.eindopdracht.Model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.Data;

import java.util.List;

@Data

@Entity(name = "Tag_table")
public class Tag {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column
    private String tag;

    @ManyToOne
    @JoinColumn(name = "Tag_id")
    private Tag tags;


    @ManyToMany(mappedBy = "tags", cascade = CascadeType.ALL)
    @JsonIgnoreProperties("tags") // Prevents infinite recursion when serializing
    private List<Post> posts; // Many tags for many posts

}
