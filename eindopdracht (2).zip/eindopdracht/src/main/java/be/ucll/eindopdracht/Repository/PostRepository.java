package be.ucll.eindopdracht.Repository;

import be.ucll.eindopdracht.Model.Playlist;
import be.ucll.eindopdracht.Model.Post;
import be.ucll.eindopdracht.Model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface PostRepository extends JpaRepository <Post, Long> {
    //Optional<Post> findPostByNameAndUserId(String naam, Long userId);

}
