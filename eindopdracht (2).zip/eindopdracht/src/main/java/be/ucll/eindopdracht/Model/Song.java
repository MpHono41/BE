package be.ucll.eindopdracht.Model;


import jakarta.persistence.*;
import lombok.*;

@Data
@Entity(name = "Song_table")
public class Song {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column
    private String name;

    @Column
    private String artist;

    @Column
    private int lengte_liedje;

    @Column
    private String album;

    @Column
    private String genre;

//    @ManyToOne //many playlists for one song
//    @JoinColumn(name = "playlist_id")
//    private Playlist playlist;
}
