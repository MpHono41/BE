package be.ucll.eindopdracht.Controller;

import be.ucll.eindopdracht.Model.User;
import be.ucll.eindopdracht.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/v1")
public class UserController {

    @Autowired
    private UserService service;

    @GetMapping("users")
    public List<User>
    getAllUsers(){
        return service.getAllUsers();
    }

    @GetMapping("user/{id}")
    public ResponseEntity<User> getPartnerById(@PathVariable("id") Long id) {
        User user = service.getUserById(id);

        return new ResponseEntity<>(user, HttpStatus.OK);
    }

    @PostMapping("user")
    public ResponseEntity<User> saveUser(@RequestBody User user){

        return new ResponseEntity<>(service.saveUser(user), HttpStatus.CREATED);
    }

    @DeleteMapping("user/{id}")
    public void deleteUserById(@PathVariable("id") Long id){
        service.deleteById(id);
    }

}
