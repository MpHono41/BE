package be.ucll.eindopdracht.Model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity(name = "Post_table") //zegt aan het project om een tabel te maken vd klasse post in DB

public class Post {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private Long id;

    private String titel;

    private int postBody;

    private int maxTags;

    @ManyToOne //many posts for one user
    private User user; //linking user class

    @ManyToMany (mappedBy = "Tag", cascade = CascadeType.ALL) //One tag for many posts
    @JsonIgnoreProperties("tags") //Bij het oproepen van een post worden tags genegeerd (zodat het niet oneindig post >< tags zou blijven oproepen)
    private List<Tag> tags; // 1 post voor meerdere tags
}
