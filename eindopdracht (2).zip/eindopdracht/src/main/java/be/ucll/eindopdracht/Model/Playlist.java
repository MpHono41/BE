package be.ucll.eindopdracht.Model;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity(name = "Playlist_table") //zegt aan het project om een tabel te maken vd klasse playlist in DB
public class Playlist {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    private int aantal_liedjes;

//    @ManyToOne //many playlists for one user
//    @JoinColumn(name = "user_id") //indiceert aan DB dat de PL gelinkt is aan een user - Bij oproepen van de PL zie je wie hem gemaakt heeft
//    @JsonIgnoreProperties("playlists")
//    private User user;

    @OneToMany(mappedBy = "playlist", cascade = CascadeType.ALL) //One song for many playlists
    @JsonIgnoreProperties("songs") //Bij het oproepen van een pl worden songs genegeerd (zodat het niet oneindig pl >< songs zou blijven oproepen)
    private List<Song> songs; // 1pl voor +++ liedjes
}
