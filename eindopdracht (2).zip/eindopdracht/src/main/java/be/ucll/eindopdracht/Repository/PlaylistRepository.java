package be.ucll.eindopdracht.Repository;


import be.ucll.eindopdracht.Model.Playlist;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository //link DB en project - geen pl repo = geen tabel voor pl
public interface PlaylistRepository extends JpaRepository<Playlist, Long> { //extends: PLrepo kan libraries uit JpaRepo gebruiken

    Optional<Playlist> findPlaylistByNameAndUserId(String naam, Long userId);

}
