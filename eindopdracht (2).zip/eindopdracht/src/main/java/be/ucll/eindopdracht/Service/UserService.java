package be.ucll.eindopdracht.Service;


import be.ucll.eindopdracht.Model.User;
import be.ucll.eindopdracht.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {

    @Autowired
    private UserRepository repo;

    public List<User> getAllUsers(){
        return repo.findAll();
    }

    public User getUserById(Long id){

        return repo.findById(id)
                .orElseThrow(); //throw new EntityNotFoundException("User not found");
    }

    public User saveUser(User user){
        return repo.save(user);
    }

    public void deleteById(Long id){
        repo.deleteById(id);
    }



}
