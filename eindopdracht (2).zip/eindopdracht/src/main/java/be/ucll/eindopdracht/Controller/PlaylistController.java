package be.ucll.eindopdracht.Controller;


import be.ucll.eindopdracht.Model.Playlist;
import be.ucll.eindopdracht.Service.PlaylistService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/v1") //shortcut voor in de code - niet in postman
public class PlaylistController {

    @Autowired
    private PlaylistService service;

    @PostMapping("user/{id}/playlist")
    public ResponseEntity<Playlist> createPlaylist(@PathVariable Long id, @RequestBody Playlist playlist) {
        return new ResponseEntity<>(service.createPlaylist(id, playlist), HttpStatus.OK);
    }

    @PostMapping("user/{user-id}/playlist/{playlist-id}/song")
    public ResponseEntity<Playlist> addSongToPlaylist(@PathVariable("user-id") Long userId, @PathVariable("playlist-id") Long playlistId, @RequestBody Long songId) {

        return new ResponseEntity<>(service.addSongToPlaylist(userId, playlistId, songId), HttpStatus.OK);
    }

    @DeleteMapping("user/{user-id}/playlist/{playlist-id}/song/{song-id}")
    public ResponseEntity<Void> deleteSongFromPlaylist(@PathVariable("user-id") Long userId, @PathVariable("playlist-id") Long playlistId, @PathVariable("song-id") Long songId) {
        try {
            service.removeSongFromPlaylist(userId, playlistId, songId);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (EntityNotFoundException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}
