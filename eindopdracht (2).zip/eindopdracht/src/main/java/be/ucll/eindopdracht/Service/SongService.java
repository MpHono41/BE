package be.ucll.eindopdracht.Service;


import be.ucll.eindopdracht.Model.Song;
import be.ucll.eindopdracht.Repository.SongRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SongService {

    @Autowired
    private SongRepository repo;

    public List<Song> getAllTheSongs(){
        return repo.findAll();
    }

    public Song saveTheSong(Song song){
        return repo.save(song);
    }

    public Song updateSong(Song song) {
        if(repo.existsById(song.getId())){
            return repo.save(song);
        } else {
            return null; //TU peux mettre un exception
        }
    }

    public void DeleteSong(Long id){
        repo.deleteById(id);
    }

    public List<Song> getSongsByAlbum(String album) {
        return repo.findByAlbum(album);
    }
}