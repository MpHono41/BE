package be.ucll.eindopdracht;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EindopdrachtApplication  { //startklasse SpringBoot

	public static void main(String[] args) {
		SpringApplication.run(EindopdrachtApplication.class, args);
	}
}

