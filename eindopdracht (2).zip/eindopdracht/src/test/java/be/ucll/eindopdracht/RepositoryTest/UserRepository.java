package be.ucll.eindopdracht.RepositoryTest;

import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

@DataJpaTest
public interface UserRepository {
}
