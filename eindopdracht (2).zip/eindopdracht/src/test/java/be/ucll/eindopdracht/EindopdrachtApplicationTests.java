package be.ucll.eindopdracht;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EindopdrachtApplicationTests {

	@Test
	void contextLoads() {
	}

}
