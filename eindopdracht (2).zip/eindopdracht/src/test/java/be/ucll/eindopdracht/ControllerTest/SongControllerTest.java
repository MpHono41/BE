package be.ucll.eindopdracht.ControllerTest;

import be.ucll.eindopdracht.Model.Song;
import be.ucll.eindopdracht.Service.SongService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class SongControllerTest {

    @MockBean
    private SongService songService;

    @Autowired
    private MockMvc mockMvc; //MockMvc ontstaat bij run

    private Song song;

    @Autowired
    private ObjectMapper objectMapper;

    @BeforeEach
    void init() {
        song = new Song();
        song.setId(1L);
        song.setName("Song Title");
        song.setArtist("Artist Name");
        song.setAlbum("Album Name");
        song.setLengte_liedje(300);
        song.setGenre("Genre");
    }

    @Test
    void getAllSongs() throws Exception {
        List<Song> songs = Arrays.asList(song);
        when(songService.getAllTheSongs()).thenReturn(songs);

        mockMvc.perform(get("/api/v1/songs"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id", is(1)))
                .andExpect(jsonPath("$[0].name", is("Song Title")))
                .andExpect(jsonPath("$[0].artist", is("Artist Name")))
                .andExpect(jsonPath("$[0].album", is("Album Name")))
                .andExpect(jsonPath("$[0].lengte_liedje", is(300)))
                .andExpect(jsonPath("$[0].genre", is("Genre")));
    }

    @Test
    void saveSong() throws Exception {
        when(songService.saveTheSong(song)).thenReturn(song);

        mockMvc.perform(post("/api/v1/song")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(song)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id", is(1)))
                .andExpect(jsonPath("$.name", is("Song Title")))
                .andExpect(jsonPath("$.artist", is("Artist Name")))
                .andExpect(jsonPath("$.album", is("Album Name")))
                .andExpect(jsonPath("$.lengte_liedje", is(300)))
                .andExpect(jsonPath("$.genre", is("Genre")));
    }

    @Test
    void updateSong_success() throws Exception {
        when(songService.updateSong(song)).thenReturn(song);

        mockMvc.perform(put("/api/v1/song/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(song)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id", is(1)))
                .andExpect(jsonPath("$.name", is("Song Title")))
                .andExpect(jsonPath("$.artist", is("Artist Name")))
                .andExpect(jsonPath("$.album", is("Album Name")))
                .andExpect(jsonPath("$.lengte_liedje", is(300)))
                .andExpect(jsonPath("$.genre", is("Genre")));
    }

    @Test
    void getSongsByAlbum_success() throws Exception {
        List<Song> songs = Arrays.asList(song);
        when(songService.getSongsByAlbum("Album Name")).thenReturn(songs);

        mockMvc.perform(get("/api/v1/song").param("album", "Album Name"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id", is(1)))
                .andExpect(jsonPath("$[0].name", is("Song Title")))
                .andExpect(jsonPath("$[0].artist", is("Artist Name")))
                .andExpect(jsonPath("$[0].album", is("Album Name")))
                .andExpect(jsonPath("$[0].lengte_liedje", is(300)))
                .andExpect(jsonPath("$[0].genre", is("Genre")));
    }

    @Test
    void getSongsByAlbum_noContent() throws Exception {
        when(songService.getSongsByAlbum("Non-Existent Album")).thenReturn(Arrays.asList());

        mockMvc.perform(get("/api/v1/song").param("album", "Non-Existent Album"))
                .andExpect(status().isNoContent());
    }
}
