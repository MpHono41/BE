package be.ucll.eindopdracht.ControllerTest;

import be.ucll.eindopdracht.Model.Playlist;
import be.ucll.eindopdracht.Service.PlaylistService;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.persistence.EntityNotFoundException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import static org.hamcrest.Matchers.is;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class PlaylistControllerTest {

    @MockBean
    private PlaylistService playlistService;

    @Autowired
    private MockMvc mockMvc;

    private Playlist playlist;

    @Autowired
    private ObjectMapper objectMapper;

    @BeforeEach
    void init() {
        playlist = new Playlist();
        playlist.setId(1L);
        playlist.setName("My Playlist");

    }

    @Test
    void createPlaylist() throws Exception {
        when(playlistService.createPlaylist(1L, playlist)).thenReturn(playlist);

        mockMvc.perform(post("/api/v1/user/1/playlist")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(playlist)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id", is(1)))
                .andExpect(jsonPath("$.name", is("My Playlist")));
    }

    @Test
    void addSongToPlaylist() throws Exception {
        when(playlistService.addSongToPlaylist(1L, 1L, 1L)).thenReturn(playlist);

        mockMvc.perform(post("/api/v1/user/1/playlist/1/song")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(1L)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id", is(1)))
                .andExpect(jsonPath("$.name", is("My Playlist")));
    }

    @Test
    void deleteSongFromPlaylist() throws Exception {
        doNothing().when(playlistService).removeSongFromPlaylist(1L, 1L, 1L);

        mockMvc.perform(delete("/api/v1/user/1/playlist/1/song/1"))
                .andExpect(status().isNoContent());
    }

    @Test
    void deleteSongFromPlaylist_NotFound() throws Exception {
        // Mock the service to throw an EntityNotFoundException
        doThrow(new EntityNotFoundException()).when(playlistService).removeSongFromPlaylist(1L, 1L, 2L);

        mockMvc.perform(delete("/api/v1/user/1/playlist/1/song/2"))
                .andExpect(status().isNotFound());
    }
}